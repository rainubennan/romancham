
// import 'package:flutter/material.dart';

// class AlertBox extends StatefulWidget {
//   const AlertBox({ Key? key }) : super(key: key);

//   @override
//   _AlertBoxState createState() => _AlertBoxState();
// }

// class _AlertBoxState extends State<AlertBox> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         child: ,
//       ),
//     );
//   }
// }
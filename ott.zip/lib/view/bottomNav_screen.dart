// import 'package:flutter/gestures.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_floating_bottom_bar/flutter_floating_bottom_bar.dart';

// class MyHomePage extends StatefulWidget {
//   MyHomePage({
//     Key? key,
//   }) : super(key: key);

//   @override
//   _MyHomePageState createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomePage>
//     with SingleTickerProviderStateMixin {
//   late int currentPage;
//   late TabController tabController;
//   final colors = Colors.red;
//   final List<Widget> screens = [
//     Center(
//       child: Card(
//         color: Colors.red,
//         child: Text(
//           'Home',
//           style: TextStyle(color: Colors.white),
//         ),
//       ),
//     ),
//     Center(
//       child: Card(
//         color: Colors.red,
//         child: Text(
//           'Search',
//           style: TextStyle(color: Colors.white),
//         ),
//       ),
//     ),
//     Center(
//       child: Card(
//         color: Colors.red,
//         child: Text(
//           'Settings',
//           style: TextStyle(color: Colors.white),
//         ),
//       ),
//     )
//   ];

//   @override
//   void initState() {
//     currentPage = 0;
//     tabController = TabController(length: 3, vsync: this);
//     tabController.animation?.addListener(
//       () {
//         final value = tabController.animation!.value.round();
//         if (value != currentPage && mounted) {
//           changePage(value);
//         }
//       },
//     );
//     super.initState();
//   }

//   void changePage(int newPage) {
//     setState(() {
//       currentPage = newPage;
//     });
//   }

//   @override
//   void dispose() {
//     tabController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final Color unselectedColor = Colors.white;

//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.black,
//         ),
//         body: BottomBar(
//           clip: Clip.none,
//           child: Stack(
//             alignment: Alignment.center,
//             clipBehavior: Clip.none,
//             children: [
//               TabBar(
//                 indicatorPadding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
//                 controller: tabController,
//                 indicator: UnderlineTabIndicator(
//                     borderSide: BorderSide(
//                       color: Colors.black,
//                       width: 4,
//                     ),
//                     insets: EdgeInsets.fromLTRB(16, 0, 16, 8)),
//                 tabs: [
//                   SizedBox(
//                     height: 55,
//                     width: 40,
//                     child: Center(
//                         child: Icon(
//                       Icons.home,
//                       color: currentPage == 0 ? colors[0] : unselectedColor,
//                     )),
//                   ),
//                   SizedBox(
//                     height: 55,
//                     width: 40,
//                     child: Center(
//                       child: Icon(
//                         Icons.search,
//                         color: currentPage == 1 ? colors[1] : unselectedColor,
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 55,
//                     width: 40,
//                     child: Center(
//                       child: Icon(
//                         Icons.account_circle_rounded,
//                         color: currentPage == 1 ? colors[1] : unselectedColor,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//           fit: StackFit.expand,
//           icon: (width, height) => Center(
//             child: IconButton(
//               padding: EdgeInsets.zero,
//               onPressed: null,
//               icon: Icon(
//                 Icons.arrow_upward_rounded,
//                 color: unselectedColor,
//                 size: width,
//               ),
//             ),
//           ),
//           borderRadius: BorderRadius.circular(500),
//           duration: Duration(milliseconds: 500),
//           curve: Curves.decelerate,
//           showIcon: true,
//           width: MediaQuery.of(context).size.width * 0.8,
//           start: 2,
//           end: 0,
//           offset: 10,
//           barAlignment: Alignment.bottomCenter,
//           iconHeight: 30,
//           iconWidth: 30,
//           reverse: false,
//           hideOnScroll: true,
//           scrollOpposite: false,
//           onBottomBarHidden: () {},
//           onBottomBarShown: () {},
//           body: (context, controller) => TabBarView(
//             controller: tabController,
//             dragStartBehavior: DragStartBehavior.down,
//             physics: const BouncingScrollPhysics(),
//             children: screens
//                 .map(
//                   (e) => InfiniteListPage(
//                     key: ValueKey('infinite_list_key#${e.toString()}'),
//                     controller: controller,
//                     color: unselectedColor,
//                   ),
//                 )
//                 .toList(),
//           ),
//         ),
//       ),
//     );
//   }
// }

// class InfiniteListPage extends StatelessWidget {
//   final Color color;
//   final ScrollController controller;
//   const InfiniteListPage(
//       {required this.color, required this.controller, Key? key})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return ListView.builder(
//       itemBuilder: (context, index) {
//         return ListTile(
//           key: ValueKey('Tab1_ListTile_$index'),
//           onTap: () {},
//           tileColor: color,
//           title: Text("$index"),
//         );
//       },
//     );
//   }
// }
import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ott/view/profile/profile.dart';

class BottomNav extends StatefulWidget {
  @override
  _BottomNavState createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  int _currentIndex = 0;

  final List<Widget> _children = [
    HomeScreen(),
    SearchScreen(),
    Profile(),
  ];

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff28282B),
      body: _children[_currentIndex],
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BottomNavigationBar(
          iconSize: 30,
          backgroundColor: Colors.black,
          selectedItemColor: Colors.red,
          unselectedItemColor: Colors.white,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_2_outlined),
              label: '',
            ),
          ],
          currentIndex: _currentIndex,
          onTap: onTabTapped,
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Home Screen'),
    );
  }
}

class SearchScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Search Screen'),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ott/view/profile/edit_profile.dart';
import 'package:ott/view/profile/settings.dart';
import 'package:ott/view/profile/wishlist.dart';

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff28282B),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(30),
            child: Row(
              children: [
                const Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: CircleAvatar(
                    radius: 70,
                    backgroundImage: NetworkImage(
                      'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671116.jpg?size=626&ext=jpg',
                    ),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'Robin K',
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ),
                    const Text(
                      'abcdefg@gmail.com',
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => EditProfile()));
                        },
                        child: Text(
                          'Edit Profile',
                          style: TextStyle(color: Colors.red.shade900),
                        ))
                  ],
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Container(
              // height: MediaQuery.of(context).size.height * .174,
              width: MediaQuery.of(context).size.width * .2,
              decoration: BoxDecoration(
                  color: Color(0xff373535),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.red.shade900)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircleAvatar(
                      backgroundColor: Colors.amber,
                      backgroundImage: AssetImage('assets/images/Icon.png'),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Get',
                          style: GoogleFonts.poppins(
                            textStyle:
                                TextStyle(color: Colors.white, fontSize: 20),
                          ),
                        ),
                        Text(
                          'Premium',
                          style: GoogleFonts.poppins(
                            textStyle:
                                TextStyle(color: Colors.white, fontSize: 20),
                          ),
                        ),
                        Text(
                          'Enjoy Endless Streaming',
                          style: GoogleFonts.poppins(
                            textStyle:
                                TextStyle(color: Colors.white, fontSize: 10),
                          ),
                        )
                      ],
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    icon: Icon(
                      Icons.arrow_right,
                      color: Colors.red.shade900,
                      size: 50,
                    ),
                    onPressed: () {},
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5, left: 15, right: 15),
            child: ListTile(
              onTap: () {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => Wishlist()));
              },
              tileColor: const Color(0xff373535),
              selectedTileColor: Colors.red.shade900,
              leading: Icon(
                Icons.watch_later_outlined,
                color: Colors.red.shade900,
              ),
              title: Text(
                'My Watchlist',
                style: GoogleFonts.poppins(
                    textStyle: TextStyle(color: Colors.white)),
              ),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_right,
                  color: Colors.red.shade900,
                  size: 30,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
            child: ListTile(
              onTap: () {},
              tileColor: const Color(0xff373535),
              selectedTileColor: Colors.red.shade900,
              leading: Icon(
                Icons.history,
                color: Colors.red.shade900,
              ),
              title: Text(
                'Transaction History',
                style: GoogleFonts.poppins(
                    textStyle: TextStyle(color: Colors.white)),
              ),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_right,
                  color: Colors.red.shade900,
                  size: 30,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
            child: ListTile(
              onTap: () {},
              tileColor: const Color(0xff373535),
              selectedTileColor: Colors.red.shade900,
              leading: Icon(
                Icons.manage_accounts_outlined,
                color: Colors.red.shade900,
              ),
              title: Text(
                'Report a Problem',
                style: GoogleFonts.poppins(
                    textStyle: TextStyle(color: Colors.white)),
              ),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_right,
                  color: Colors.red.shade900,
                  size: 30,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
            child: ListTile(
              onTap: () {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => Settings()));
              },
              tileColor: const Color(0xff373535),
              selectedTileColor: Colors.red.shade900,
              leading: Icon(
                Icons.tune_outlined,
                color: Colors.red.shade900,
              ),
              title: Text(
                'Settings',
                style: GoogleFonts.poppins(
                    textStyle: TextStyle(color: Colors.white)),
              ),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_right,
                  color: Colors.red.shade900,
                  size: 30,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
            child: ListTile(
              onTap: () {},
              tileColor: const Color(0xff373535),
              selectedTileColor: Colors.red.shade900,
              leading: Icon(
                Icons.logout,
                color: Colors.red.shade900,
              ),
              title: Text(
                'Logout',
                style: GoogleFonts.poppins(
                    textStyle: TextStyle(color: Colors.white)),
              ),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_right,
                  color: Colors.red.shade900,
                  size: 30,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
            ),
          )
        ],
      ),
    );
  }
}

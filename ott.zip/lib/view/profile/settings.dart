import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff28282B),
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Color(0xff28282B),
        title: Text(
          'Settings',
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 18),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 100, left: 10, right: 10),
            child: ListTile(
              tileColor: Color(0xff373535),
              title: Text(
                'Change Password',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              trailing: Icon(
                Icons.arrow_right,
                color: Colors.red.shade900,
                size: 35,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            child: ListTile(
              tileColor: Color(0xff373535),
              title: Text(
                'Device Management',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              trailing: Icon(
                Icons.arrow_right,
                color: Colors.red.shade900,
                size: 35,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            child: ListTile(
              tileColor: Color(0xff373535),
              title: Text(
                'Privacy Policy',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              trailing: Icon(
                Icons.arrow_right,
                color: Colors.red.shade900,
                size: 35,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            child: ListTile(
              tileColor: Color(0xff373535),
              title: Text(
                'Terms & Conditions',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              trailing: Icon(
                Icons.arrow_right,
                color: Colors.red.shade900,
                size: 35,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
